(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const app = $("#app");
  const searchInput = $("#global-search");
  const searchPanel = $("#search-panel");
  const nav = $("#main-nav");
  const KIND_RU = { weapon: "Оружие", armor: "Броня", acc: "Аксессуар", tool: "Инструмент", mat: "Материал", summon: "Призыв", potion: "Расходник" };
  const CLS_RU = { melee: "Воин", ranged: "Стрелок", mage: "Маг", summoner: "Призыватель", rogue: "Плут", all: "Все" };
  const T = (s) => (CODEX.linkify ? CODEX.linkify(s) : s);
  const RU = (s) => (CODEX.ru ? CODEX.ru(s) : s);
  const loc = (s) => {
    if (s == null) return "";
    let t = String(s);
    if (CODEX._linkers) {
      CODEX._linkers.forEach(({ re, id }) => {
        const info = CODEX.lex && CODEX.lex[id];
        if (!info) return;
        t = t.replace(re, info.ru);
      });
    }
    return CODEX.linkify ? CODEX.linkify(t) : t;
  };
  const mast = (title, lead) => `
    <div class="page-head">
      <h1>${title}</h1>
      <p>${lead}</p>
    </div>`;
  const shelf = (title, count, inner, open = false) => `
    <details class="shelf"${open ? " open" : ""}>
      <summary>
        <i class="shelf-plus" aria-hidden="true"></i>
        <span class="shelf-t">${title}</span>
        ${count != null && count !== "" ? `<span class="shelf-n">${count}</span>` : ""}
      </summary>
      <div class="shelf-body">${inner}</div>
    </details>`;

  const tt = document.getElementById("tt");
  const fillTT = (info) => {
    if (!tt || !info) return;
    tt.innerHTML = `
      <div class="tt-type">${info.type}</div>
      <div class="tt-ru">${info.ru}</div>
      <div class="tt-en">${info.en}</div>
      <p>${info.desc}</p>
      ${info.where ? `<p><b>Где взять / где это</b> — ${info.where}</p>` : ""}
      ${info.craft ? `<p><b>Крафт</b> — ${info.craft}</p>` : ""}
      ${info.used ? `<p><b>Зачем</b> — ${info.used}</p>` : ""}
    `;
  };
  const placeTT = (el) => {
    const r = el.getBoundingClientRect();
    const tw = tt.offsetWidth || 360;
    const th = tt.offsetHeight || 180;
    let x = r.left;
    let y = r.bottom + 8;
    if (x + tw > innerWidth - 8) x = innerWidth - tw - 8;
    if (x < 8) x = 8;
    if (y + th > innerHeight - 8) y = r.top - th - 8;
    if (y < 8) y = 8;
    tt.style.left = x + "px";
    tt.style.top = y + "px";
  };
  document.addEventListener("mouseover", (e) => {
    const el = e.target.closest && e.target.closest(".tip");
    if (!el || !tt) return;
    const info = CODEX.lex && CODEX.lex[el.dataset.id];
    if (!info) return;
    fillTT(info);
    tt.hidden = false;
    placeTT(el);
  });
  document.addEventListener("mouseout", (e) => {
    const el = e.target.closest && e.target.closest(".tip");
    if (!el || !tt) return;
    if (e.relatedTarget && el.contains(e.relatedTarget)) return;
    tt.hidden = true;
  });
  document.addEventListener("click", (e) => {
    const el = e.target.closest && e.target.closest(".tip");
    if (!el || !tt) return;
    const info = CODEX.lex && CODEX.lex[el.dataset.id];
    if (!info) return;
    if (!tt.hidden && tt.dataset.id === el.dataset.id) { tt.hidden = true; return; }
    fillTT(info);
    tt.dataset.id = el.dataset.id;
    tt.hidden = false;
    placeTT(el);
    e.preventDefault();
  });

  const store = {
    get() { try { return JSON.parse(localStorage.getItem("calamity-codex") || "{}"); } catch { return {}; } },
    set(p) { localStorage.setItem("calamity-codex", JSON.stringify({ ...store.get(), ...p })); }
  };

  /* ---------- themed particles ---------- */
  const FX = (() => {
    const c = $("#embers");
    if (!c) return { set() {} };
    const ctx = c.getContext("2d");
    let w, h, dots = [], mode = "embers";
    const pal = {
      embers:  ["232,120,60", "255,80,40"],
      leaves:  ["122,180,80", "200,160,60"],
      sparks:  ["182,255,74", "220,255,160"],
      stars:   ["232,184,74", "255,255,220"],
      bubbles: ["61,205,192", "160,240,255"],
      blobs:   ["155,140,255", "200,120,200"],
      sand:    ["232,184,74", "200,140,60"],
      acid:    ["182,224,74", "120,200,40"],
      spores:  ["110,200,255", "180,230,255"],
      drip:    ["196,30,90", "120,10,40"],
      dust:    ["160,176,200", "100,110,130"],
      snow:    ["200,235,255", "255,255,255"],
      ash:     ["255,60,70", "80,20,20"],
      pollen:  ["140,224,90", "220,200,80"],
      gold:    ["255,224,138", "255,180,60"],
      warp:    ["122,224,255", "208,122,255"],
      fire:    ["255,140,40", "255,60,20"],
      ritual:  ["255,77,109", "180,40,255"]
    };
    const spawn = () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      r: Math.random() * 2.2 + 0.4,
      s: Math.random() * 0.7 + 0.12,
      a: Math.random() * 0.5 + 0.12,
      vx: (Math.random() - 0.5) * 0.6,
      t: Math.random() * 100,
      c: (pal[mode] || pal.embers)[Math.random() < 0.6 ? 0 : 1]
    });
    const resize = () => {
      w = c.width = innerWidth; h = c.height = innerHeight;
      dots = Array.from({ length: 36 }, spawn);
    };
    resize();
    addEventListener("resize", resize);
    const tick = () => {
      ctx.clearRect(0, 0, w, h);
      dots.forEach((d) => {
        d.t += 0.02;
        if (mode === "bubbles") { d.y -= d.s; d.x += Math.sin(d.t) * 0.4; }
        else if (mode === "snow" || mode === "spores" || mode === "pollen" || mode === "leaves") {
          d.y += d.s * 0.55; d.x += Math.sin(d.t) * 0.8 + d.vx;
        } else if (mode === "sand") { d.y += d.s * 0.3; d.x += d.s * 1.4; }
        else if (mode === "drip" || mode === "acid") { d.y += d.s * 1.4; }
        else if (mode === "warp") { d.x += d.vx * 4; d.y += Math.sin(d.t) * 0.4; }
        else { d.y -= d.s; d.x += Math.sin(d.y * 0.01) * 0.25; }
        if (d.y < -8) d.y = h + 8;
        if (d.y > h + 8) d.y = -8;
        if (d.x < -8) d.x = w + 8;
        if (d.x > w + 8) d.x = -8;
        ctx.beginPath();
        ctx.fillStyle = `rgba(${d.c},${d.a})`;
        if (mode === "warp") {
          ctx.fillRect(d.x, d.y, 10 + d.s * 8, 1);
        } else if (mode === "leaves") {
          ctx.save(); ctx.translate(d.x, d.y); ctx.rotate(d.t);
          ctx.fillRect(-d.r, -d.r / 2, d.r * 2, d.r); ctx.restore();
        } else {
          ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2); ctx.fill();
        }
      });
      requestAnimationFrame(tick);
    };
    tick();
    return {
      set(name) {
        mode = name || "embers";
        dots.forEach((d) => { d.c = (pal[mode] || pal.embers)[Math.random() < 0.6 ? 0 : 1]; });
      }
    };
  })();

  function fillRail(html) {
    const extra = document.getElementById("rail-extra");
    if (extra) extra.innerHTML = html || "";
  }

  function applyTheme(q) {
    const accent = (q && q.accent) || "#e8b84a";
    const fx = (q && q.fx) || "embers";
    document.body.style.setProperty("--accent", accent);
    document.body.style.setProperty("--theme-image", q && q.bg ? `url("${q.bg}")` : "none");
    document.body.style.setProperty("--theme-filter", (q && q.filter) || "none");
    document.body.dataset.fx = fx;
    FX.set(fx);
  }

  const ICO = {
    steps: `<svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M9 4h6v2H9zm-4 4h14v2H5zm2 4h10v2H7zm3 4h4v6h-4z"/></svg>`,
    map: `<svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M12 2a7 7 0 0 0-7 7c0 5.25 7 13 7 13s7-7.75 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6a2.5 2.5 0 0 1 0 5.5z"/></svg>`,
    bag: `<svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M7 7V6a5 5 0 0 1 10 0v1h3v14H4V7h3zm2 0h6V6a3 3 0 0 0-6 0z"/></svg>`,
    craft: `<svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M2 19h20v2H2zm3-3 5-5 2 2 7-7 2 2-9 9-2-2-3 3z"/></svg>`,
    sword: `<svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M21 3 11 13l-1.5 4.5L14 16 21 3zM8 15l-5 5 1 1 5-5-1-1z"/></svg>`,
    check: `<svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg>`,
    tip: `<svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M9 21h6v-1H9zm3-19a7 7 0 0 0-4 12.7V17h8v-2.3A7 7 0 0 0 12 2z"/></svg>`
  };
  const h3 = (ico, text) => `<h3><span class="h3-ico">${ico}</span>${text}</h3>`;

  function eraBadge(era) {
    const map = { pre: ["pre", "Прехардмод"], hard: ["hard", "Хардмод"], post: ["post", "Пост-ML"], end: ["end", "Финал"] };
    const [cls, label] = map[era] || ["pre", era];
    const pretty = { pre: "Прехардмод", hard: "Хардмод", post: "После Луны", end: "Финал" };
    return `<span class="badge ${cls}">${pretty[era] || label}</span>`;
  }

  function route() {
    const hash = location.hash.replace(/^#/, "") || "/";
    const [path, q] = hash.split("?");
    const params = Object.fromEntries(new URLSearchParams(q || ""));
    const parts = path.split("/").filter(Boolean);
    document.querySelectorAll("#main-nav a").forEach((a) => {
      const on = a.dataset.nav === "home" ? !parts.length : parts[0] === a.dataset.nav;
      a.classList.toggle("active", on);
    });
    nav.classList.remove("open");
    document.getElementById("rail")?.classList.remove("open");
    const scrim = document.getElementById("rail-scrim");
    if (scrim) scrim.hidden = true;
    document.body.dataset.view = parts[0] || "home";
    if (!parts.length) { applyTheme(null); return renderHome(); }
    if (parts[0] === "novice") return renderNovice(Number(params.q) || store.get().quest || 1);
    if (parts[0] === "wiki") { applyTheme(null); return renderWiki(params.tab || "progress"); }
    if (parts[0] === "bosses") { applyTheme(null); return renderBosses(params.id); }
    if (parts[0] === "crafts") { applyTheme(null); return renderCrafts(params.q || ""); }
    if (parts[0] === "items") { applyTheme(null); return renderItems(params); }
    if (parts[0] === "lex") { applyTheme(null); return renderLex(); }
    if (parts[0] === "biomes") { applyTheme(null); return renderBiomes(); }
    applyTheme(null); renderHome();
  }

  function renderHome() {
    applyTheme(null);
    fillRail("");
    document.body.style.setProperty("--theme-image", "none");
    app.innerHTML = `
      <section class="hero">
        <div class="hero-bg"></div>
        <div class="hero-inner">
          <div class="kicker">Террария · Каламити ${CODEX.version}</div>
          <h1>Каламити<span>Кодекс</span></h1>
          <p class="lede">С квеста 1 — если только поставил мод. Справочник — если уже в игре и нужно быстро.</p>
          <div class="mode-grid">
            <a class="mode-card" href="#/novice?q=1">
              <img src="assets/novice.jpg" alt="" />
              <span class="tag">Я новичок</span>
              <h2>С квеста 1</h2>
              <p>Дом, дроны, небо, море, червь… до ведьмы. Выбери класс слева. Подчёркнутое слово — наведи мышь.</p>
            </a>
            <a class="mode-card" href="#/wiki">
              <img src="assets/veteran.jpg" alt="" />
              <span class="tag">Уже играю</span>
              <h2>Сжатый справочник</h2>
              <p>Боссы, сеты, материалы, биомы — коротко, по этапам.</p>
            </a>
          </div>
        </div>
      </section>
      <section class="home-strip">
        <div class="jump-grid">
          <a class="jump" href="#/novice?q=1"><small>30 шагов</small><b>Путь новичка</b></a>
          <a class="jump" href="#/bosses"><small>по порядку</small><b>Боссы</b></a>
          <a class="jump" href="#/items"><small>где и зачем</small><b>Предметы</b></a>
          <a class="jump" href="#/crafts"><small>стол и ингредиенты</small><b>Крафты</b></a>
          <a class="jump" href="#/biomes"><small>куда идти</small><b>Биомы</b></a>
          <a class="jump" href="#/lex"><small>наведи мышь</small><b>Словарь</b></a>
        </div>
        <div class="stat-row">
          <div class="stat"><b>${CODEX.quests.length}</b><span>квестов</span></div>
          <div class="stat"><b>${CODEX.items.length}</b><span>предметов</span></div>
          <div class="stat"><b>${CODEX.bosses.length}</b><span>боссов</span></div>
          <div class="stat"><b>${CODEX.crafts.length}</b><span>крафтов</span></div>
        </div>
        <div class="era-grid">${CODEX.eras.map((e) => `<article class="era-card"><h3>${e.title}</h3><ol>${e.items.map((i) => `<li>${i}</li>`).join("")}</ol></article>`).join("")}</div>
      </section>
    `;
  }

  function questProgress() {
    const s = store.get();
    return { done: new Set(s.doneQuests || []), tasks: s.tasks || {}, cls: s.cls || "melee", itemFilter: s.itemFilter || "mine" };
  }

  const esc = (s) => String(s ?? "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const plainName = (name) => {
    const lex = CODEX.lookup ? CODEX.lookup(name) : null;
    if (lex) {
      const ru = lex.ru || name;
      const en = lex.en && lex.en.toLowerCase() !== String(ru).toLowerCase() ? lex.en : "";
      return { ru, en };
    }
    const ru = CODEX.ru ? CODEX.ru(name) : name;
    const en = /[A-Za-z]/.test(String(name)) && String(name) !== ru ? name : "";
    return { ru, en };
  };
  const splitIngs = (s) => {
    if (Array.isArray(s)) return s.map((x) => String(x).trim()).filter(Boolean);
    const raw = String(s || "").replace(/\s*@\s*.+$/, "").trim();
    if (!raw) return [];
    const parts = raw.split(/\s+\+\s+/).map((x) => x.trim()).filter(Boolean);
    if (parts.length >= 2 && parts.every((p) => p.length < 72)) return parts;
    return [raw];
  };
  const pullStation = (c) => {
    let station = String(c.station || "").trim();
    let ings = String(c.ings || c.r || "").trim();
    const at = ings.match(/\s*@\s*(.+)$/);
    if (at) {
      if (!station) station = at[1].trim();
      ings = ings.replace(/\s*@\s*.+$/, "").trim();
    }
    const pref = ings.match(/^(Печь|Верстак|Наковальня|Железная наковальня|Свинцовая наковальня|Алтарь зла|Алтарь|Адская кузня|Хардмод-наковальня|Мифриловая наковальня|Книжный шкаф|Манипулятор|Древний манипулятор|Космическая наковальня|Кузня Дрейдона|Взломостойка|Мастерская|Мастерская гоблина|Алхимия \/ наковальня|Алтарь \/ наковальня)[:：]\s*(.+)$/i);
    if (pref) {
      if (!station) station = pref[1];
      ings = pref[2];
    }
    return { station, ings };
  };
  function craftCard(c) {
    const src = c.t ? { name: c.t, ings: c.r, why: c.w, station: c.station } : c;
    const { ru, en } = plainName(src.name);
    const pulled = pullStation(src);
    const ings = splitIngs(pulled.ings);
    const why = String(src.why || "").trim();
    const station = pulled.station;
    return `<article class="craft-card">
      ${station ? `<div class="station-tag">${esc(station)}</div>` : ""}
      <b>${esc(ru)}${en ? `<span class="en-sub">в игре: ${esc(en)}</span>` : ""}</b>
      ${ings.length ? `<ul class="ings-list">${ings.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : ""}
      ${why ? `<div class="item-foot"><div class="fact"><span>Зачем</span><p>${esc(why)}</p></div></div>` : ""}
    </article>`;
  }
  function biomeCard(b) {
    const title = b.name;
    const en = b.en || "";
    const loot = Array.isArray(b.loot) ? b.loot : String(b.loot || "").split(/,\s*/).filter(Boolean);
    const d = String(b.danger || "");
    const lvl = b.dangerLvl || (/смерт/i.test(d) ? "dead" : /высок/i.test(d) ? "high" : /средн/i.test(d) ? "mid" : "low");
    return `<article class="biome-card">
      <div class="shot" style="background-image:url('${b.img || "assets/hero.jpg"}');filter:${b.filter || "none"}">
        <span class="danger-pill ${lvl}">${esc(d)}</span>
      </div>
      <div class="body">
        <h3>${esc(title)}</h3>
        ${en ? `<span class="en-sub">в игре: ${esc(en)}</span>` : ""}
        ${b.desc ? `<p class="desc">${esc(b.desc)}</p>` : ""}
        <div class="item-foot">
          ${b.where ? `<div class="fact"><span>Где</span><p>${esc(b.where)}</p></div>` : ""}
          ${b.when ? `<div class="fact"><span>Когда</span><p>${esc(b.when)}</p></div>` : ""}
          ${loot.length ? `<div class="fact"><span>Лут</span><div class="loot-chips">${loot.map((x) => `<em>${esc(x)}</em>`).join("")}</div></div>` : ""}
          ${b.need ? `<div class="fact"><span>Бери</span><p>${esc(b.need)}</p></div>` : ""}
          ${b.tip ? `<div class="fact"><span>Совет</span><p>${esc(b.tip)}</p></div>` : ""}
        </div>
      </div>
    </article>`;
  }


  const SPRITE_FIX = {
    "Wooden Sword / Bow / Staff из мешка": "Wooden_Sword",
    "Hermes / Flurry / Sailfish / Dunerider Boots": "Hermes_Boots",
    "Cloud / Blizzard / Sandstorm in a Bottle": "Cloud_in_a_Bottle",
    "Wulfrum Hat & Goggles": "Wulfrum_Hat_and_Goggles",
    "Wulfrum Jacket": "Wulfrum_Jacket",
    "Wulfrum Overalls": "Wulfrum_Overalls",
    "Wulfrum Blade / Screwdriver": "Wulfrum_Blade",
    "Wulfrum Bow / Blunderbuss": "Wulfrum_Bow",
    "Wulfrum Prosthesis / Staff": "Wulfrum_Prosthesis",
    "Железная / свинцовая наковальня": "Iron_Anvil",
    "Кровать": "Bed",
    "Dubious Plating / Mysterious Circuitry": "Dubious_Plating",
    "Enchanted Sword / Terragrim": "Enchanted_Sword",
    "Worm Food / Bloody Spine": "Worm_Food",
    "Musket / The Undertaker": "Musket",
    "Vilethorn / Crimson Rod": "Vilethorn",
    "Ball O' Hurt / The Meatball": "Ball_O'_Hurt",
    "Bee Gun / Bee's Knees / Hive-Five": "Bee_Gun",
    "Muramasa / Aqua Scepter / Magic Missile / Handgun": "Muramasa",
    "Warrior / Ranger / Sorcerer / Summoner / Rogue Emblem": "Warrior_Emblem",
    "Cobalt / Palladium armor": "Cobalt_armor",
    "Frostspark / Lightning / Terraspark Boots": "Terraspark_Boots",
    "Soul of Sight / Might / Fright": "Soul_of_Sight",
    "Seedler / Pygmy Staff / Venus Magnum / Leaf Blower": "Seedler",
    "Tsunami / Razorblade Typhoon / Tempest Staff / Flairon": "Tsunami",
    "Empress оружия / Terraprisma": "Terraprisma",
    "Soaring Insignia / Wings Empress": "Soaring_Insignia",
    "Celestial Sigil / столбы": "Celestial_Sigil",
    "Solar / Vortex / Nebula / Stardust / Empyrean armor": "Solar_Flare_armor",
    "Mycoroot / Hyphae Rod / Fungicide": "Mycoroot",
    "Acid Gun / Toxibow": "Toxibow",
    "Slimy Saddle / Hook": "Slimy_Saddle",
    "Chlorophyte armor / оружие": "Chlorophyte_armor",
    "Plaguebringer / Plague Reaper armor": "Plaguebringer_armor",
    "God Slayer / Silva armor": "God_Slayer_armor"
  };
  const KIND_SVG = {
    weapon: '<svg class="item-ico" viewBox="0 0 48 48" aria-hidden="true"><path fill="#e8c56b" d="M40 6 22 24l-2 8 8-2L46 12z"/><path fill="#9a9186" d="M20 28 8 40l4 2 10-12z"/></svg>',
    armor: '<svg class="item-ico" viewBox="0 0 48 48" aria-hidden="true"><path fill="#c8b896" d="M24 6 10 12v10c0 10 6 16 14 20 8-4 14-10 14-20V12z"/></svg>',
    acc: '<svg class="item-ico" viewBox="0 0 48 48" aria-hidden="true"><circle cx="24" cy="26" r="10" fill="none" stroke="#d4ae5a" stroke-width="3"/><circle cx="24" cy="26" r="4" fill="#d4ae5a"/><path d="M20 10h8v6h-8z" fill="#8a8070"/></svg>',
    tool: '<svg class="item-ico" viewBox="0 0 48 48" aria-hidden="true"><path fill="#8aa4d4" d="M10 38 28 20l4 4L14 42z"/><path fill="#d4ae5a" d="M30 8l10 10-8 4-6-6z"/></svg>',
    mat: '<svg class="item-ico" viewBox="0 0 48 48" aria-hidden="true"><path fill="#7ad3a0" d="M24 6 40 18 34 40H14L8 18z"/></svg>',
    summon: '<svg class="item-ico" viewBox="0 0 48 48" aria-hidden="true"><path fill="#d07aff" d="M24 6c6 8 14 10 14 20 0 8-6 16-14 16S10 34 10 26C10 16 18 14 24 6z"/></svg>',
    potion: '<svg class="item-ico" viewBox="0 0 48 48" aria-hidden="true"><path fill="#6ecbff" d="M20 6h8v8l8 14c0 8-6 14-12 14S12 36 12 28l8-14z"/></svg>'
  };
  function spriteKey(it) {
    if (it.sprite) return it.sprite;
    if (SPRITE_FIX[it.name]) return SPRITE_FIX[it.name];
    const lex = CODEX.lookup && CODEX.lookup(it.name);
    let en = (lex && lex.en) || "";
    if (!/[A-Za-z]/.test(en)) en = String(it.name || "");
    en = en.split(/\s*\/\s*/)[0].replace(/\s+из мешка.*$/i, "").replace(/&/g, "and");
    en = en.replace(/[^A-Za-z0-9' _-]/g, "").trim();
    return en.replace(/\s+/g, "_");
  }
  function bindSprites(root) {
    (root || document).querySelectorAll("img.item-art").forEach((img) => {
      if (img.dataset.bound) return;
      img.dataset.bound = "1";
      img.addEventListener("error", function step() {
        const n = Number(img.dataset.try || 0);
        const file = img.dataset.file;
        if (!file) { fail(); return; }
        const enc = encodeURIComponent(file);
        if (n === 0) { img.dataset.try = "1"; img.src = "https://calamitymod.wiki.gg/wiki/Special:FilePath/" + enc + ".gif"; }
        else if (n === 1) { img.dataset.try = "2"; img.src = "https://terraria.wiki.gg/wiki/Special:FilePath/" + enc + ".png"; }
        else if (n === 2) { img.dataset.try = "3"; img.src = "https://terraria.wiki.gg/wiki/Special:FilePath/" + enc + ".gif"; }
        else fail();
        function fail() {
          img.removeEventListener("error", step);
          const wrap = img.parentElement;
          const ico = KIND_SVG[img.dataset.kind] || KIND_SVG.mat;
          img.remove();
          if (wrap) wrap.insertAdjacentHTML("afterbegin", ico);
        }
      });
    });
  }
  function itemCard(it, cls, filter) {

    const mine = it.cls === "all" || it.cls === cls;
    const hide = filter === "mine" && !mine;
    const dim = filter === "all" && !mine;
    const lex = CODEX.lookup ? CODEX.lookup(it.name) : null;
    const title = it.nameRu || (lex ? lex.ru : it.name);
    const enRaw = lex ? lex.en : (/[A-Za-z]/.test(it.name) ? it.name : "");
    const en = enRaw && enRaw.toLowerCase() !== String(title).toLowerCase() ? enRaw : "";
    const kind = KIND_RU[it.kind] || it.kind;
    const stats = (it.stats || "").trim();
    const fake = !stats || stats === kind || /^(Оружие|Броня|Аксессуар|Инструмент|Материал|Предмет|Расходник)/i.test(stats);
    const desc = (it.desc || (lex && lex.desc) || "").trim();
    const why = (it.why || "").trim();
    const showWhy = why && why !== desc;
    const getPlain = String(it.get || "").replace(/\bCalamity\b/g, "Каламити").trim();
    const rec = String(it.rec || "").trim();
    const showGet = getPlain && !/^крафт\.?$/i.test(getPlain);
    const local = (CODEX.spriteOf ? CODEX.spriteOf(it) : (CODEX.sprites && (CODEX.sprites[it.name] || CODEX.sprites[it.nameRu]))) || "";
    return `<article class="item-card has-art ${hide ? "hidden" : ""} ${dim ? "dim" : ""} ${mine && filter !== "all" ? "mine" : ""}">
      <div class="item-shot ${it.cls} ${it.kind || ""}">
        ${local ? `<img class="item-art" alt="" src="${local}" onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'item-slot'}))" />` : `<div class="item-slot"></div>`}
        <span class="kind-pill">${esc(kind)}</span>
        <span class="tag-cls ${it.cls}">${CLS_RU[it.cls] || it.cls}</span>
      </div>
      <div class="body">
        <b>${esc(title)}${en ? `<span class="en-sub">в игре: ${esc(en)}</span>` : ""}</b>
        ${!fake ? `<div class="stats-line">${esc(stats)}</div>` : ""}
        ${desc ? `<p class="desc">${esc(desc)}</p>` : ""}
        <div class="item-foot">
          ${showGet ? `<div class="fact"><span>Где</span><p>${esc(getPlain)}</p></div>` : ""}
          ${rec ? `<div class="fact"><span>Крафт</span><p>${esc(rec)}</p></div>` : ""}
          ${showWhy ? `<div class="fact"><span>Зачем</span><p>${esc(why)}</p></div>` : ""}
        </div>
      </div>
    </article>`;
  }

  function renderNovice(id) {
    const quests = CODEX.quests;
    const q = quests.find((x) => x.id === id) || quests[0];
    const { done, tasks, cls, itemFilter } = questProgress();
    const pct = Math.round((done.size / quests.length) * 100);
    store.set({ quest: q.id });
    applyTheme(q);
    const gear = q.gear || [];
    const counts = {
      all: gear.length,
      mine: gear.filter((i) => i.cls === "all" || i.cls === cls).length
    };

    app.innerHTML = `
      <div class="page">
        <div class="novice-layout">
          <aside class="quest-side">
            <div class="progress-box">
              <strong>${done.size} / ${quests.length} квестов</strong>
              <div class="bar"><i style="width:${pct}%"></i></div>
              <div class="class-pick">
                ${CODEX.classes.map((c) => `<button data-cls="${c.id}" class="${c.id === cls ? "active" : ""}" title="${({
                  melee: "Бьёт мечом вблизи",
                  ranged: "Лук и пушки издалека",
                  mage: "Заклинания, нужна мана",
                  summoner: "Помощники бьют за тебя",
                  rogue: "Кинжалы и скрытность"
                })[c.id]}">${c.name}</button>`).join("")}
              </div>
              <p style="font-size:11px;color:var(--muted);margin-top:8px">${({
                melee: "Воин: стой ближе, бей мечом или цепом.",
                ranged: "Стрелок: бегай, стреляй. Нужны стрелы или пули.",
                mage: "Маг: синяя шкала маны. Не стой вплотную.",
                summoner: "Призыватель: ты уворачиваешься, бьют помощники.",
                rogue: "Плут: постой без ударов — удар из скрытности сильнее."
              })[cls]}</p>
            </div>
            ${quests.map((item) => `
              <div class="q-item ${item.id === q.id ? "active" : ""} ${done.has(item.id) ? "done" : ""}" data-qid="${item.id}">
                <div class="q-num">${String(item.id).padStart(2, "0")}</div>
                <div><b>${item.title}</b><small>${item.subtitle}</small></div>
              </div>
            `).join("")}
          </aside>
          <article class="quest">
            <div class="frame-c tl"></div><div class="frame-c tr"></div>
            <div class="frame-c bl"></div><div class="frame-c br"></div>
            <div class="quest-hero">
              <div class="pic" style="background-image:url('${q.bg || "assets/hero.jpg"}');filter:${q.filter || "none"}"></div>
              <div class="hero-glow"></div>
              <div class="inner">
                <div class="rune-row">
                  ${eraBadge(q.era)}
                  <span class="rune">Квест ${String(q.id).padStart(2, "0")} из ${quests.length}</span>
                </div>
                <h2>${q.title}</h2>
                <p class="mood">${q.mood || q.subtitle}</p>
              </div>
            </div>
            <div class="quest-pad">
            ${q.objective ? `<div class="obj-box"><strong>Сейчас</strong>${T(q.objective)}</div>` : ""}
            ${shelf("Зачем это", "", `<p class="story" style="margin:0">${T(q.story)}</p><p class="how-tip" style="margin-top:10px">Наведи на слово — всплывёт, что это.</p>`)}
            ${q.steps ? shelf("Шаги", q.steps.length, `<div class="steps">${q.steps.map((s, i) => `<div class="step"><div class="step-n">${i + 1}</div><div><h4>${T(s.t)}</h4><p>${T(s.d)}</p></div></div>`).join("")}</div>`, true) : ""}
            ${shelf("Куда идти", (q.where || []).length, `<div class="cards">${q.where.map((x, i) => `<div class="info-card"><em class="pin">${i + 1}</em><b>${esc(plainName(x.t).ru)}</b><p>${T(x.d)}</p></div>`).join("")}</div>`)}
            ${shelf("Предметы", `${counts.mine}/${counts.all}`, `
              <div class="filter-row">
                <button class="mini ${itemFilter === "mine" ? "on" : ""}" data-if="mine">Мой класс</button>
                <button class="mini ${itemFilter === "all" ? "on" : ""}" data-if="all">Все</button>
              </div>
              <div class="item-grid">
                ${gear.map((it) => itemCard(it, cls, itemFilter)).join("") || q.collect.map((x) => `<div class="item-card"><b>${T(RU(x.t))}</b><p class="desc">${T(x.d)}</p></div>`).join("")}
              </div>`)}
            ${shelf("Крафт", (q.crafts || []).length, `<div class="craft-grid">${(q.crafts || []).map((x) => craftCard(x)).join("")}</div>`)}
            ${shelf("Кого бить", (q.fight || []).length, q.fight.map((x) => `<div class="kill-card"><b>${esc(plainName(x.t).ru)}</b><p>${T(x.d)}</p></div>`).join(""))}
            ${shelf("Чеклист", (q.tasks || []).length, `<div class="tasks">${q.tasks.map((t, i) => {
              const key = q.id + ":" + i;
              const on = !!(tasks[key]);
              return `<label class="task ${on ? "checked" : ""}"><input type="checkbox" data-task="${key}" ${on ? "checked" : ""} /><span>${T(t)}</span></label>`;
            }).join("")}</div>`)}
            ${shelf("Советы", "", `<div class="tips">${q.tips.map((t) => `<div class="hint">${T(t)}</div>`).join("")}</div><div class="class-note"><b>${CLS_RU[cls]}:</b> ${T(q.classTips[cls])}</div>`)}
            </div>
            <div class="quest-nav">
              <button class="btn ghost" data-go="${q.id - 1}" ${q.id === 1 ? "disabled" : ""}>← Назад</button>
              <button class="btn" data-finish="${q.id}">Квест выполнен →</button>
            </div>
          </article>
        </div>
      </div>
    `;

    app.querySelectorAll("[data-qid]").forEach((el) => el.onclick = () => location.hash = `#/novice?q=${el.dataset.qid}`);
    app.querySelectorAll("[data-cls]").forEach((el) => el.onclick = () => { store.set({ cls: el.dataset.cls }); renderNovice(q.id); });
    app.querySelectorAll("[data-if]").forEach((el) => el.onclick = () => { store.set({ itemFilter: el.dataset.if }); renderNovice(q.id); });
    app.querySelectorAll("[data-task]").forEach((el) => el.onchange = () => {
      const s = store.get();
      store.set({ tasks: { ...(s.tasks || {}), [el.dataset.task]: el.checked } });
      el.closest(".task").classList.toggle("checked", el.checked);
    });
    const fin = app.querySelector("[data-finish]");
    if (fin) fin.onclick = () => {
      const set = new Set(store.get().doneQuests || []);
      set.add(q.id);
      store.set({ doneQuests: [...set] });
      const next = CODEX.quests.find((x) => x.id === q.id + 1);
      location.hash = `#/novice?q=${next ? next.id : q.id}`;
    };
    const back = app.querySelector("[data-go]");
    if (back) back.onclick = () => { if (q.id > 1) location.hash = `#/novice?q=${q.id - 1}`; };
    const side = app.querySelector(".quest-side");
    if (side) fillRail(side.innerHTML);
    const rail = document.getElementById("rail-extra");
    rail?.querySelectorAll("[data-qid]").forEach((el) => {
      el.onclick = () => location.hash = `#/novice?q=${el.dataset.qid}`;
    });
    rail?.querySelectorAll("[data-cls]").forEach((el) => {
      el.onclick = () => { store.set({ cls: el.dataset.cls }); renderNovice(q.id); };
    });
    rail?.querySelector(".q-item.active")?.scrollIntoView({ block: "nearest" });
    const saved = store.get().openSh || {};
    app.querySelectorAll(".shelf").forEach((el) => {
      const key = q.id + ":" + (el.querySelector(".shelf-t")?.textContent || "");
      if (saved[key] === true) el.open = true;
      if (saved[key] === false) el.open = false;
      el.addEventListener("toggle", () => {
        store.set({ openSh: { ...(store.get().openSh || {}), [key]: el.open } });
      });
    });
    bindSprites(app);
  }

  function renderLex() {
    fillRail("");
    applyTheme(null);
    const groups = {};
    Object.values(CODEX.lex || {}).forEach((e) => {
      (groups[e.type] = groups[e.type] || []).push(e);
    });
    app.innerHTML = `
      <div class="page">
        ${mast("Словарь", "Полка по типу. На карточке — что это, где взять, зачем.")}
        ${Object.entries(groups).map(([type, arr]) => shelf(esc(type), arr.length, `
          <div class="item-grid">
            ${arr.map((e) => `<article class="item-card">
              <div class="item-top"><b>${esc(e.ru)}</b><span class="tag-cls all">${esc(e.type)}</span></div>
              ${e.en ? `<span class="en-sub">в игре: ${esc(e.en)}</span>` : ""}
              <p class="desc">${esc(e.desc)}</p>
              <div class="item-foot">
                ${e.where ? `<div class="fact"><span>Где</span><p>${esc(e.where)}</p></div>` : ""}
                ${e.used ? `<div class="fact"><span>Зачем</span><p>${esc(e.used)}</p></div>` : ""}
                ${e.craft ? `<div class="fact"><span>Крафт</span><p>${esc(e.craft)}</p></div>` : ""}
              </div>
            </article>`).join("")}
          </div>`)).join("")}
      </div>
    `;
  }

  function wikiCard(title, rows) {
    return `<article class="item-card">
      <b>${esc(title)}</b>
      <div class="item-foot">${rows.map(([k, v]) => v ? `<div class="fact"><span>${k}</span><p>${esc(v)}</p></div>` : "").join("")}</div>
    </article>`;
  }

  function renderWiki(tab) {
    const tabs = [
      ["progress", "Прогрессия"],
      ["armor", "Броня"],
      ["mats", "Материалы"],
      ["hp", "Сердца и мана"],
      ["mech", "Механики"]
    ];
    fillRail("");
    app.innerHTML = `
      <div class="page">
        ${mast("Справочник", "Коротко по этапам. Полные маршруты — в предметах и квестах.")}
        <div class="chips">
          ${tabs.map(([id, name]) => `<button class="chip ${tab === id ? "active" : ""}" data-tab="${id}">${name}</button>`).join("")}
        </div>
        <div id="wiki-body"></div>
      </div>
    `;
    app.querySelectorAll("[data-tab]").forEach((b) => b.onclick = () => location.hash = `#/wiki?tab=${b.dataset.tab}`);
    const body = $("#wiki-body");
    if (tab === "armor") {
      body.innerHTML = `<div class="item-grid">${CODEX.armors.map((a) => wikiCard(a.name, [["Когда", a.when], ["Из", a.mat], ["Заметка", a.note]])).join("")}</div>`;
    } else if (tab === "mats") {
      body.innerHTML = `<div class="item-grid">${CODEX.materials.map((m) => wikiCard(m.name, [["Этап", m.when], ["Откуда", m.src], ["Зачем", m.use]])).join("")}</div>`;
    } else if (tab === "hp") {
      body.innerHTML = `<div class="item-grid">${CODEX.hpUps.map((h) => wikiCard(h.name, [["Когда", h.when], ["Эффект", h.bonus]])).join("")}</div>`;
    } else if (tab === "mech") {
      body.innerHTML = `<div class="item-grid">${CODEX.mechanics.map((m) => wikiCard(m.name, [["Суть", m.d]])).join("")}</div>`;
    } else {
      body.innerHTML = CODEX.quests.map((q) => shelf(
        `${String(q.id).padStart(2, "0")}. ${q.title}`,
        q.subtitle,
        `<p class="story" style="margin:0 0 10px">${esc(q.mood || q.subtitle || "")}</p><a href="#/novice?q=${q.id}">Открыть квест →</a>`
      )).join("");
    }
  }

  function renderItems(params) {
    fillRail("");
    const cls = params.cls || "all";
    const kind = params.kind || "all";
    const qid = params.q || "all";
    const search = (params.s || "").toLowerCase();
    const list = CODEX.items.filter((i) => {
      if (cls !== "all" && i.cls !== "all" && i.cls !== cls) return false;
      if (kind !== "all" && i.kind !== kind) return false;
      if (qid !== "all" && String(i.q) !== String(qid)) return false;
      if (search && !`${i.name} ${i.nameRu || ""} ${i.get} ${i.why} ${i.rec || ""} ${i.desc || ""}`.toLowerCase().includes(search)) return false;
      return true;
    });
    app.innerHTML = `
      <div class="page">
        ${mast("Предметы", "Русское имя сразу. На карточке — что это, где взять, зачем.")}
        <div class="chips">
          <button class="chip ${cls === "all" ? "active" : ""}" data-p="cls" data-v="all">Все классы</button>
          ${CODEX.classes.map((c) => `<button class="chip ${cls === c.id ? "active" : ""}" data-p="cls" data-v="${c.id}">${c.name}</button>`).join("")}
        </div>
        <div class="chips">
          <button class="chip ${kind === "all" ? "active" : ""}" data-p="kind" data-v="all">Тип: все</button>
          ${Object.entries(KIND_RU).map(([k, n]) => `<button class="chip ${kind === k ? "active" : ""}" data-p="kind" data-v="${k}">${n}</button>`).join("")}
        </div>
        <div class="filter-bar">
          <label class="search-wrap">
            <svg viewBox="0 0 24 24" width="16" height="16"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="1.7"/></svg>
            <input id="item-s" placeholder="Название или «где взять»…" value="${params.s || ""}" />
          </label>
          <select id="item-q">
            <option value="all" ${qid === "all" ? "selected" : ""}>Все квесты</option>
            ${CODEX.quests.map((q) => `<option value="${q.id}" ${String(qid) === String(q.id) ? "selected" : ""}>${q.id}. ${q.title}</option>`).join("")}
          </select>
        </div>
        <p class="found">Найдено: ${list.length}</p>
        <div class="item-grid">${list.map((it) => itemCard(it, cls === "all" ? "melee" : cls, "all")).join("")}</div>
      </div>
    `;
    const build = (over = {}) => {
      const n = { cls, kind, q: qid, s: params.s || "", ...over };
      const qs = new URLSearchParams();
      Object.entries(n).forEach(([k, v]) => { if (v && v !== "all" || k === "s" && v) qs.set(k, v); });
      location.hash = "#/items" + (qs.toString() ? "?" + qs.toString() : "");
    };
    app.querySelectorAll("[data-p]").forEach((b) => b.onclick = () => build({ [b.dataset.p]: b.dataset.v }));
    const inp = $("#item-s");
    let t;
    inp.oninput = () => { clearTimeout(t); t = setTimeout(() => build({ s: inp.value }), 220); };
    const qsel = $("#item-q");
    if (qsel) qsel.onchange = () => build({ q: qsel.value });
    bindSprites(app);
  }

  function renderBosses() {
    fillRail("");
    app.innerHTML = `
      <div class="page">
        ${mast("Боссы по порядку", "Всё на карточке: где бить, чем звать, что падает.")}
        <div class="chips">
          <button class="chip active" data-era="all">Все</button>
          <button class="chip" data-era="pre">Прехардмод</button>
          <button class="chip" data-era="hard">Хардмод</button>
          <button class="chip" data-era="post">После Луны</button>
          <button class="chip" data-era="end">Финал</button>
        </div>
        <div class="item-grid" id="boss-grid">${CODEX.bosses.map(bossCard).join("")}</div>
        <h2 class="section-title" style="margin-top:28px">Мини-боссы</h2>
        <div class="item-grid">${CODEX.minis.map(miniCard).join("")}</div>
      </div>
    `;
    const grid = $("#boss-grid");
    app.querySelectorAll("[data-era]").forEach((ch) => ch.onclick = () => {
      app.querySelectorAll("[data-era]").forEach((x) => x.classList.remove("active"));
      ch.classList.add("active");
      grid.innerHTML = CODEX.bosses.filter((b) => ch.dataset.era === "all" || b.era === ch.dataset.era).map(bossCard).join("");
    });
  }

  function bossCard(b) {
    return `<article class="item-card boss-card">
      <div class="item-top">
        <span class="boss-num">#${String(b.n).padStart(2, "0")} · ${esc(b.type)}</span>
        ${eraBadge(b.era)}
      </div>
      <b>${esc(b.name)}${b.en ? `<span class="en-sub">в игре: ${esc(b.en)}</span>` : ""}</b>
      ${b.tip ? `<p class="desc">${esc(b.tip)}</p>` : ""}
      <div class="item-foot">
        <div class="fact"><span>Где</span><p>${esc(b.where)}</p></div>
        <div class="fact"><span>Когда</span><p>${esc(b.when)}</p></div>
        <div class="fact"><span>Зови</span><p>${esc(b.summon)}</p></div>
        <div class="fact"><span>Дроп</span><p>${esc(b.drops)}</p></div>
        ${b.q ? `<a class="boss-link" href="#/novice?q=${b.q}">Квест ${b.q} →</a>` : ""}
      </div>
    </article>`;
  }

  function miniCard(m) {
    return `<article class="item-card">
      <b>${esc(m.name)}${m.en ? `<span class="en-sub">в игре: ${esc(m.en)}</span>` : ""}</b>
      <div class="item-foot">
        <div class="fact"><span>Когда</span><p>${esc(m.when)}</p></div>
        <div class="fact"><span>Где</span><p>${esc(m.where)}</p></div>
        <div class="fact"><span>Дроп</span><p>${esc(m.drops)}</p></div>
      </div>
    </article>`;
  }

  function renderCrafts(filter) {
    const q = (filter || "").toLowerCase();
    const seen = new Set();
    const list = CODEX.crafts.filter((c) => {
      const key = String(c.name || "").toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      const blob = `${c.name} ${c.ings} ${c.why} ${c.stage} ${c.station || ""}`;
      const ru = (CODEX.ru ? CODEX.ru(c.name) : c.name) || "";
      return !q || `${blob} ${ru}`.toLowerCase().includes(q);
    });
    const groups = [];
    const map = {};
    list.forEach((c) => {
      const stage = c.stage || "Прочее";
      if (!map[stage]) { map[stage] = []; groups.push(stage); }
      map[stage].push(c);
    });
    fillRail("");
    app.innerHTML = `
      <div class="page">
        ${mast("Крафты", "Полка по этапу. На карточке — стол, ингредиенты и зачем это нужно.")}
        <label class="search-wrap">
          <svg viewBox="0 0 24 24" width="16" height="16"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="1.7"/></svg>
          <input id="craft-filter" placeholder="Название, материал, этап…" value="${filter || ""}" />
        </label>
        ${groups.map((stage, i) => shelf(esc(stage), map[stage].length, `
          <div class="craft-grid">${map[stage].map((c) => craftCard(c)).join("")}</div>`, i === 0 || !!q)).join("")}
      </div>
    `;
    const inp = $("#craft-filter");
    let t;
    inp.oninput = () => { clearTimeout(t); t = setTimeout(() => { location.hash = `#/crafts?q=${encodeURIComponent(inp.value)}`; }, 200); };
  }

  function renderBiomes() {
    fillRail("");
    app.innerHTML = `
      <div class="page">
        ${mast("Биомы", "Где это в мире, когда туда идти, что брать с собой и что унести.")}
        <div class="biome-grid">
          ${CODEX.biomes.map((b) => biomeCard(b)).join("")}
        </div>
      </div>
    `;
  }

  function searchAll(q) {
    q = q.trim().toLowerCase();
    if (q.length < 2) { searchPanel.classList.add("hidden"); return; }
    const hits = [];
    CODEX.quests.forEach((x) => {
      if (`${x.title} ${x.subtitle} ${x.story} ${x.mood || ""} ${x.objective || ""}`.toLowerCase().includes(q))
        hits.push({ href: `#/novice?q=${x.id}`, title: `Квест ${x.id}: ${x.title}`, sub: x.subtitle });
    });
    Object.values(CODEX.lex || {}).forEach((x) => {
      if (`${x.ru} ${x.en} ${x.desc} ${x.where}`.toLowerCase().includes(q))
        hits.push({ href: `#/lex`, title: x.ru, sub: `${x.type} · ${x.en}` });
    });
    (CODEX.items || []).forEach((x) => {
      const title = x.nameRu || x.name;
      if (`${x.name} ${title} ${x.get} ${x.why} ${x.desc || ""}`.toLowerCase().includes(q))
        hits.push({ href: `#/items?s=${encodeURIComponent(x.name)}`, title, sub: x.get });
    });
    CODEX.bosses.forEach((x) => {
      if (`${x.name} ${x.en || ""} ${x.drops} ${x.summon}`.toLowerCase().includes(q))
        hits.push({ href: `#/bosses`, title: x.name, sub: x.summon });
    });
    CODEX.crafts.forEach((x) => {
      if (`${x.name} ${x.ings} ${x.why}`.toLowerCase().includes(q))
        hits.push({ href: `#/crafts?q=${encodeURIComponent(x.name)}`, title: x.name, sub: x.ings });
    });
    searchPanel.classList.remove("hidden");
    searchPanel.innerHTML = hits.length
      ? hits.slice(0, 20).map((h) => `<a class="search-hit" href="${h.href}"><b>${h.title}</b><small>${h.sub || ""}</small></a>`).join("")
      : `<div class="search-hit"><b>Ничего не найдено</b><small>Попробуй «виктайд», «скория», «морские останки»</small></div>`;
    searchPanel.querySelectorAll("a").forEach((a) => a.onclick = () => searchPanel.classList.add("hidden"));
  }

  searchInput.addEventListener("input", () => searchAll(searchInput.value));
  searchInput.addEventListener("focus", () => { if (searchInput.value.length >= 2) searchAll(searchInput.value); });
  document.addEventListener("click", (e) => {
    if (!searchPanel.contains(e.target) && e.target !== searchInput) searchPanel.classList.add("hidden");
  });
  const railEl = document.getElementById("rail");
  const scrim = document.getElementById("rail-scrim");
  $("#menu-btn").onclick = () => {
    railEl?.classList.toggle("open");
    if (scrim) scrim.hidden = !railEl?.classList.contains("open");
  };
  if (scrim) scrim.onclick = () => {
    railEl?.classList.remove("open");
    scrim.hidden = true;
  };
  addEventListener("hashchange", route);
  route();
})();
